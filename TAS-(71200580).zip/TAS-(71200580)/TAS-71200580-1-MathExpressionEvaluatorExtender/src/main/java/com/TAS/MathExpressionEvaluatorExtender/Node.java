package com.TAS.MathExpressionEvaluatorExtender;

public class Node {
    public abstract double hitung();
}
