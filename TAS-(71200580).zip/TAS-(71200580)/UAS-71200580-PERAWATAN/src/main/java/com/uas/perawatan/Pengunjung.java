package com.uas.perawatan;

public class Pengunjung {
    private String nama;
    private int usia;
    private String alamat;
    private String penyakit;
    private int levelPenyakit;
    private String status;

    public Pengunjung(String nama, int usia, String alamat, String penyakit, int levelPenyakit, String status) {
        this.nama = nama;
        this.usia = usia;
        this.alamat = alamat;
        this.penyakit = penyakit;
        this.levelPenyakit = levelPenyakit;
        this.status = status;
    }


}
